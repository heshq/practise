
#include <string>

#include "expression.h"
#include "syntax_tree.h"
#include "compare_expression_factory.h"

using namespace std;

class SmallerExpressionFactory;

class SmallerExpression : public Expression {
    friend class SmallerExpressionFactory;
    private:
        Expression *_left, *_right;
        SmallerExpression( Expression *left, Expression *right)
            : _left( left), _right( right)
        {
        }
        virtual void detach() noexcept override
        {
            _left = NULL;
            _right = NULL;
        }

    public:
        virtual ~SmallerExpression() noexcept
        {
            if ( _left)
                delete _left;
            if ( _right)
                delete _right;
        }

        virtual int eval() override
        {
            return _left->eval() < _right->eval();
        }
};

class SmallerExpressionFactory : public CompareExpressionFactory {
    public:
        static SmallerExpressionFactory &instance() noexcept
        {
            static SmallerExpressionFactory factory;
            return factory;
        }

    private:
        static bool _registered;

        // Can NOT be inherited:
        SmallerExpressionFactory() {}

        virtual bool _create( SyntaxTree &tree, int begin) override
        {
            if ( begin + 2 >= tree.size)
                return false;
            SyntaxTree::Node const &left = tree[ begin];
            SyntaxTree::Node const &middle = *( left.next);
            SyntaxTree::Node const &right = *( middle.next);
            if ( middle.is_expression() || middle.character != '<'
                    || left.is_character() || right.is_character())
                return false;
            SmallerExpression *exp;
            try {
                exp = new SmallerExpression( left.expression, right.expression);
            } catch ( exception &e) {
                string msg( "error: fail to create smaller instance: ");
                msg += e.what();
                throw msg;
            }
            tree.compose( begin, begin + 3, exp);
            return true;
        }
};

bool
SmallerExpressionFactory::_registered =
    CompareExpressionFactory::instance().registering( &SmallerExpressionFactory::instance());


