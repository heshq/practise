
#include <string>

#include "expression.h"
#include "syntax_tree.h"
#include "expression_factory.h"

using namespace std;

class TernaryExpressionFactory;

class TernaryExpression : public Expression {
    friend class TernaryExpressionFactory;
    private:
        Expression *_left, *_right, *_middle;
        TernaryExpression( Expression *left, Expression *middle, Expression *right)
            : _left( left), _right( right), _middle( middle)
        {
        }
        virtual void detach() noexcept override
        {
            _left = NULL;
            _right = NULL;
            _middle = NULL;
        }

    public:
        virtual ~TernaryExpression() noexcept
        {
            if ( _left)
                delete _left;
            if ( _right)
                delete _right;
            if ( _middle)
                delete _middle;
        }

        virtual int eval() override
        {
            return _left->eval() ? _middle->eval() : _right->eval();
        }
};

class TernaryExpressionFactory : public ExpressionFactory {
    public:
        virtual unsigned priority() const noexcept override
        {
            return 13;
        }
        virtual bool left_to_right() const noexcept override
        {
            return false;
        }
        static TernaryExpressionFactory &instance() noexcept
        {
            static TernaryExpressionFactory factory;
            return factory;
        }

    private:
        static bool _registered;

        // Can NOT be inherited:
        TernaryExpressionFactory() {}

        virtual bool _create( SyntaxTree &tree, int begin) override
        {
            if ( begin + 4 >= tree.size)
                return false;
            SyntaxTree::Node const &left = tree[ begin];
            SyntaxTree::Node const &question = *( left.next);
            SyntaxTree::Node const &middle = *( question.next);
            SyntaxTree::Node const &colon = *( middle.next);
            SyntaxTree::Node const &right = *( colon.next);
            if ( left.is_character() || right.is_character() || middle.is_character()
                    || question.is_expression() || question.character != '?'
                    || colon.is_expression()    || colon.character != ':')
                return false;
            TernaryExpression *exp;
            try {
                exp = new TernaryExpression( left.expression, middle.expression, right.expression);
            } catch ( exception &e) {
                string msg( "error: fail to create ternary instance: ");
                msg += e.what();
                throw msg;
            }
            tree.compose( begin, begin + 5, exp);
            return true;
        }
};

bool
TernaryExpressionFactory::_registered =
    ExpressionFactory::instance().registering( &TernaryExpressionFactory::instance());


