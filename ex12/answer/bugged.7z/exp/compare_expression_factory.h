#ifndef _COMPARE_EXPRESSION_FACTORY_H
#define _COMPARE_EXPRESSION_FACTORY_H

#include "syntax_tree.h"
#include "expression_factory.h"

class CompareExpressionFactory : public ExpressionFactory {
    private:
        static bool _registered;

        virtual bool _create( SyntaxTree &tree, int begin) override;

    public:
        static CompareExpressionFactory &instance() noexcept;
        virtual unsigned priority() const noexcept override;

};

#endif

