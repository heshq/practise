
#include <iostream>
#include <exception>
#include <vector>
#include "expression_factory.h"

using namespace std;

bool
PriorityCompare::operator()( ExpressionFactory const *a, ExpressionFactory const *b)
{
    return a->priority() > b->priority();
}

ExpressionFactory::~ExpressionFactory() noexcept
{
}

ExpressionFactory &
ExpressionFactory::instance() noexcept
{
    static ExpressionFactory factory;
    return factory;
}

bool
ExpressionFactory::registering( ExpressionFactory *factory) noexcept
{
    if ( factory)
        try {
            _factories.push( factory);
            return true;
        } catch ( exception &e) {
            cerr << "warning: exception occured: " << e.what() << endl;
            return false;
        }
    return false;
}

ExpressionFactory::ExpressionFactory() noexcept
{
}

unsigned
ExpressionFactory::priority() const noexcept
{
    return 0;
}

bool
ExpressionFactory::left_to_right() const noexcept
{
    return true;
}

// use factory to build as much expressions as it can:
bool
ExpressionFactory::_try( ExpressionFactory &factory, SyntaxTree &tree)
{
    vector<int> created;
    if ( factory.left_to_right())
        for ( int i = 0; i < tree.size; i ++)
            if ( factory._create( tree, i))
                created.push_back( i);
    else
        for ( int i = tree.size - 1; i >= 0; i --)
            if ( factory._create( tree, i))
                created.push_back( i);
    if ( created.size() <= 0)
        return false;
    if ( ExpressionFactory::_recursion( tree))
        return true;
    if ( factory.left_to_right())
        for ( int i = created.size() - 1; i >= 0; i --) {
            tree[ created[ i]].expression->detach();
            delete tree[ created[ i]].expression;
            tree.decompose( created[ i]);
        }
    else
        for ( auto it = created.begin(); it != created.end(); ++ it) {
            tree[ *it].expression->detach();
            delete tree[ *it].expression;
            tree.decompose( *it);
        }
    return false;
}

bool
ExpressionFactory::_recursion( SyntaxTree &tree)
{
    if ( tree.size <= 1 && tree[ 0].is_expression())
        return true;
    for ( auto it = _factories.begin(); it != _factories.end(); ++ it)
        if ( _try( **it, tree))
            return true;
    return false;
}

bool
ExpressionFactory::_create( SyntaxTree &tree, int begin)
{
    return false;
}

Expression *
ExpressionFactory::create( char const *str, int begin, int end)
{
    SyntaxTree tree( str, begin, end);
    if ( _recursion( tree))
        return tree[ 0].expression;
    else
        return NULL;
}


