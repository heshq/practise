
#include <string>

#include "expression.h"
#include "syntax_tree.h"
#include "expression_factory.h"

using namespace std;

class BracketExpressionFactory;

class BracketExpression : public Expression {
    friend class BracketExpressionFactory;
    private:
        Expression *_inner;
        BracketExpression( Expression *inner)
            : _inner( inner)
        {
        }
        virtual void detach() noexcept override
        {
            _inner = NULL;
        }

    public:
        virtual ~BracketExpression() noexcept
        {
            if ( _inner)
                delete _inner;
        }

        virtual int eval() override
        {
            return _inner->eval();
        }
};

class BracketExpressionFactory : public ExpressionFactory {
    public:
        virtual unsigned priority() const noexcept override
        {
            return 1;
        }
        static BracketExpressionFactory &instance() noexcept
        {
            static BracketExpressionFactory factory;
            return factory;
        }

    private:
        static bool _registered;

        // Can NOT be inherited:
        BracketExpressionFactory() {}

        virtual bool _create( SyntaxTree &tree, int begin) override
        {
            if ( begin + 2 >= tree.size)
                return false;
            SyntaxTree::Node const &left = tree[ begin];
            SyntaxTree::Node const &middle = *( left.next);
            SyntaxTree::Node const &right = *( middle.next);
            if ( middle.is_character()
                    || left.is_expression() || left.character != '('
                    || right.is_expression() || right.character != ')')
                return false;
            BracketExpression *exp;
            try {
                exp = new BracketExpression( middle.expression);
            } catch ( exception &e) {
                string msg( "error: fail to create bracket instance: ");
                msg += e.what();
                throw msg;
            }
            tree.compose( begin, begin + 3, exp);
            return true;
        }
};

bool
BracketExpressionFactory::_registered =
    ExpressionFactory::instance().registering( &BracketExpressionFactory::instance());


