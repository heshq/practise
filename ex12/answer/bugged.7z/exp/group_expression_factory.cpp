
#include "group_expression_factory.h"

bool
GroupExpressionFactory::_create( SyntaxTree &tree, int position)
{
    for ( auto it = _factories.begin(); it != _factories.end(); ++ it)
        if ( ( *it)->_create( tree, position))
            return true;
    return false;
}

GroupExpressionFactory &
GroupExpressionFactory::instance() noexcept
{
    static GroupExpressionFactory factory;
    return factory;
}

unsigned
GroupExpressionFactory::priority() const noexcept
{
    return 4;
}

bool
GroupExpressionFactory::_registered =
    ExpressionFactory::instance().registering( &GroupExpressionFactory::instance());


