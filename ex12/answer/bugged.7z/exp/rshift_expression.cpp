
#include <string>

#include "expression.h"
#include "syntax_tree.h"
#include "shift_expression_factory.h"

using namespace std;

class RShiftExpressionFactory;

class RShiftExpression : public Expression {
    friend class RShiftExpressionFactory;
    private:
        Expression *_left, *_right;
        RShiftExpression( Expression *left, Expression *right)
            : _left( left), _right( right)
        {
        }
        virtual void detach() noexcept override
        {
            _left = NULL;
            _right = NULL;
        }

    public:
        virtual ~RShiftExpression() noexcept
        {
            if ( _left)
                delete _left;
            if ( _right)
                delete _right;
        }

        virtual int eval() override
        {
            int left = _left->eval();
            int right = _right->eval();
            if ( right >= 0)
                return left >> right;
            else
                return left << -right;
        }
};

class RShiftExpressionFactory : public ShiftExpressionFactory {
    public:
        static RShiftExpressionFactory &instance() noexcept
        {
            static RShiftExpressionFactory factory;
            return factory;
        }

    private:
        static bool _registered;

        // Can NOT be inherited:
        RShiftExpressionFactory() {}

        virtual bool _create( SyntaxTree &tree, int begin) override
        {
            if ( begin + 3 >= tree.size)
                return false;
            SyntaxTree::Node const &left = tree[ begin];
            SyntaxTree::Node const &middle1 = *( left.next);
            SyntaxTree::Node const &middle2 = *( middle1.next);
            SyntaxTree::Node const &right = *( middle2.next);
            if ( left.is_character() || right.is_character()
                    || middle1.is_expression() || middle1.character != '>'
                    || middle2.is_expression() || middle2.character != '>')
                return false;
            RShiftExpression *exp;
            try {
                exp = new RShiftExpression( left.expression, right.expression);
            } catch ( exception &e) {
                string msg( "error: fail to create shift-right instance: ");
                msg += e.what();
                throw msg;
            }
            tree.compose( begin, begin + 4, exp);
            return true;
        }
};

bool
RShiftExpressionFactory::_registered =
    ShiftExpressionFactory::instance().registering( &RShiftExpressionFactory::instance());


