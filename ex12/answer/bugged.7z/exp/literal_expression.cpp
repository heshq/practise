
#include <climits>
#include <string>

#include "expression.h"
#include "syntax_tree.h"
#include "expression_factory.h"

using namespace std;

class LiteralExpressionFactory;

class LiteralExpression : public Expression {
    friend class LiteralExpressionFactory;
    private:
        int _number;
        LiteralExpression( int number)
            : _number( number)
        {
        }
        virtual void detach() noexcept override
        {
        }
    public:
        virtual int eval() noexcept override
        {
            return _number;
        }
};

class LiteralExpressionFactory : public ExpressionFactory {
    public:
        virtual unsigned priority() const noexcept override
        {
            return 0;
        }
        static LiteralExpressionFactory &instance() noexcept
        {
            static LiteralExpressionFactory factory;
            return factory;
        }

    private:
        static bool _registered;

        // Can NOT be inherited:
        LiteralExpressionFactory() {}

        virtual bool _create( SyntaxTree &tree, int begin) override
        {
            if ( tree[ begin].is_expression())
                return false;
            int number = 0;
            int count = 0;
            SyntaxTree::Node const *end = &( tree[ begin]);
            while ( end && end->is_character() && end->character >= '0' && end->character <= '9') {
                if ( number > INT_MAX / 10 || number * 10 > INT_MAX - ( end->character - '0') ) {
                    string msg( "error: number used exceeded integer limit");
                    throw msg;
                }
                number = number * 10 + ( end->character - '0');
                count ++;
                end = end->next;
            }
            if ( ! count)
                return false;
            LiteralExpression *exp;
            try {
                exp = new LiteralExpression( number);
            } catch ( exception &e) {
                string msg( "error: fail to create literal instance: ");
                msg += e.what();
                throw msg;
            }
            tree.compose( begin, begin + count, exp);
            return true;
        }
};

bool
LiteralExpressionFactory::_registered =
    ExpressionFactory::instance().registering( &LiteralExpressionFactory::instance());

