#ifndef _SHIFT_EXPRESSION_FACTORY_H
#define _SHIFT_EXPRESSION_FACTORY_H

#include "syntax_tree.h"
#include "expression_factory.h"

class ShiftExpressionFactory : public ExpressionFactory {
    private:
        static bool _registered;

        virtual bool _create( SyntaxTree &tree, int begin) override;

    public:
        static ShiftExpressionFactory &instance() noexcept;
        virtual unsigned priority() const noexcept override;

};

#endif

