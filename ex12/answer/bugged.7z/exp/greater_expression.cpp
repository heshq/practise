
#include <string>

#include "expression.h"
#include "syntax_tree.h"
#include "compare_expression_factory.h"

using namespace std;

class GreaterExpressionFactory;

class GreaterExpression : public Expression {
    friend class GreaterExpressionFactory;
    private:
        Expression *_left, *_right;
        GreaterExpression( Expression *left, Expression *right)
            : _left( left), _right( right)
        {
        }
        virtual void detach() noexcept override
        {
            _left = NULL;
            _right = NULL;
        }

    public:
        virtual ~GreaterExpression() noexcept
        {
            if ( _left)
                delete _left;
            if ( _right)
                delete _right;
        }

        virtual int eval() override
        {
            return _left->eval() > _right->eval();
        }
};

class GreaterExpressionFactory : public CompareExpressionFactory {
    public:
        static GreaterExpressionFactory &instance() noexcept
        {
            static GreaterExpressionFactory factory;
            return factory;
        }

    private:
        static bool _registered;

        // Can NOT be inherited:
        GreaterExpressionFactory() {}

        virtual bool _create( SyntaxTree &tree, int begin) override
        {
            if ( begin + 2 >= tree.size)
                return false;
            SyntaxTree::Node const &left = tree[ begin];
            SyntaxTree::Node const &middle = *( left.next);
            SyntaxTree::Node const &right = *( middle.next);
            if ( middle.is_expression() || middle.character != '>'
                    || left.is_character() || right.is_character())
                return false;
            GreaterExpression *exp;
            try {
                exp = new GreaterExpression( left.expression, right.expression);
            } catch ( exception &e) {
                string msg( "error: fail to create greater instance: ");
                msg += e.what();
                throw msg;
            }
            tree.compose( begin, begin + 3, exp);
            return true;
        }
};

bool
GreaterExpressionFactory::_registered =
    CompareExpressionFactory::instance().registering( &GreaterExpressionFactory::instance());


