#ifndef _ORDERED_LIST_H
#define _ORDERED_LIST_H

#include <functional>   // std::less
#include <list>

template< typename T, typename Compare >
class _ordered_list_base : protected std::list< T > {
    protected:
        static Compare less;
    public:
        using std::list< T >::begin;
        using std::list< T >::end;
        using std::list< T >::clear;
        using std::list< T >::operator=;
        using std::list< T >::iterator;
        using std::list< T >::const_iterator;
};

template< typename T, typename Compare>
Compare _ordered_list_base< T, Compare >::less;

template< typename T, typename Compare = std::less< T > >
class ordered_list : public _ordered_list_base< T, Compare > {
    public:
        ordered_list() {}

        void push( T const &data)
        {
            auto it = this->begin();
            while ( it != this->end() && _ordered_list_base< T, Compare >::less( *it, data))
                ++ it;
            std::list< T >::insert( it, data);
        }

};

#endif


