#include <iostream>
#include "expression.h"

using namespace std;

int main()
{
    string line;
    Expression *exp = NULL;
    while( getline( cin, line))
        try {
            exp = Expression::parse( line);
            if ( exp)
                cout << exp->eval() << endl;
            else
                cerr << "error: fail to parse expression: '" << line << '\'' << endl;
            delete exp;
            exp = NULL;
        } catch ( string &msg) {
            cerr << msg << endl;
            if ( exp)
                delete exp;
        }
   return 0;
}

