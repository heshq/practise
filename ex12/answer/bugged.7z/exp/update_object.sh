#!/usr/bin/bash

###
# 
# @File   : update_object.sh   
# @Author : alexander.here@gmail.com
# @Date   : 2015-05-11 01:44   
# @Brief  :  
# 
###

for file in *.cpp
do
	name="${file%%.cpp}"
	echo "OBJ += ${name}.o"
	echo "${name}.o : $file"
	echo -e '\t$(CC) -c $< $(CC_FLAG) -O2 -o $@'
	echo
	echo "OBJ_D += ${name}.debug.o"
	echo "${name}.debug.o : $file"
	echo -e '\t$(CC) -c $< $(CC_FLAG) -O0 -g -o $@'
	echo
done > objects.mk


# End of 'update_object.sh' 

