
#include <string>

#include "expression.h"
#include "syntax_tree.h"
#include "field_expression_factory.h"

using namespace std;

class DivideExpressionFactory;

class DivideExpression : public Expression {
    friend class DivideExpressionFactory;
    private:
        Expression *_left, *_right;
        DivideExpression( Expression *left, Expression *right)
            : _left( left), _right( right)
        {
        }
        virtual void detach() noexcept override
        {
            _left = NULL;
            _right = NULL;
        }

    public:
        virtual ~DivideExpression() noexcept
        {
            if ( _left)
                delete _left;
            if ( _right)
                delete _right;
        }

        virtual int eval() override
        {
            int right = _right->eval();
            if ( ! right) { // IF NOT RIGHT
                string msg( "error: divide by zero");
                throw msg;
            }
            int left = _left->eval();
            return left / right;
        }
};

class DivideExpressionFactory : public FieldExpressionFactory {
    public:
        static DivideExpressionFactory &instance() noexcept
        {
            static DivideExpressionFactory factory;
            return factory;
        }

    private:
        static bool _registered;

        // Can NOT be inherited:
        DivideExpressionFactory() {}

        virtual bool _create( SyntaxTree &tree, int begin) override
        {
            if ( begin + 2 >= tree.size)
                return false;
            SyntaxTree::Node const &left = tree[ begin];
            SyntaxTree::Node const &middle = *( left.next);
            SyntaxTree::Node const &right = *( middle.next);
            if ( middle.is_expression() || middle.character != '/'
                    || left.is_character() || right.is_character())
                return false;
            DivideExpression *exp;
            try {
                exp = new DivideExpression( left.expression, right.expression);
            } catch ( exception &e) {
                string msg( "error: fail to create divide instance: ");
                msg += e.what();
                throw msg;
            }
            tree.compose( begin, begin + 3, exp);
            return true;
        }
};

bool
DivideExpressionFactory::_registered =
    FieldExpressionFactory::instance().registering( &DivideExpressionFactory::instance());


