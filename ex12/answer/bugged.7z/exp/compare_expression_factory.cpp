
#include "compare_expression_factory.h"

bool
CompareExpressionFactory::_create( SyntaxTree &tree, int position)
{
    for ( auto it = _factories.begin(); it != _factories.end(); ++ it)
        if ( ( *it)->_create( tree, position))
            return true;
    return false;
}

CompareExpressionFactory &
CompareExpressionFactory::instance() noexcept
{
    static CompareExpressionFactory factory;
    return factory;
}

unsigned
CompareExpressionFactory::priority() const noexcept
{
    return 6;
}

bool
CompareExpressionFactory::_registered =
    ExpressionFactory::instance().registering( &CompareExpressionFactory::instance());


