#include <cstring>  // strlen()

#include "expression.h"
#include "expression_factory.h"
#include "syntax_tree.h"

using namespace std;

Expression *
Expression::parse( std::string const &str, int begin, int end)
{
    return parse( str.c_str(), begin, end);
}

Expression *
Expression::parse( char const *str, int begin, int end)
{
    if ( end < 0)
        end = strlen( str);
    return ExpressionFactory::instance().create( str, begin, end);
}

Expression::~Expression() noexcept
{
}

