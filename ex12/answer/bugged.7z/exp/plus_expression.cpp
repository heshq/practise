
#include <string>

#include "expression.h"
#include "syntax_tree.h"
#include "group_expression_factory.h"

using namespace std;

class PlusExpressionFactory;

class PlusExpression : public Expression {
    friend class PlusExpressionFactory;
    private:
        Expression *_left, *_right;
        PlusExpression( Expression *left, Expression *right)
            : _left( left), _right( right)
        {
        }
        virtual void detach() noexcept override
        {
            _left = NULL;
            _right = NULL;
        }

    public:
        virtual ~PlusExpression() noexcept
        {
            if ( _left)
                delete _left;
            if ( _right)
                delete _right;
        }

        virtual int eval() override
        {
            return _left->eval() + _right->eval();
        }
};

class PlusExpressionFactory : public GroupExpressionFactory {
    public:
        static PlusExpressionFactory &instance() noexcept
        {
            static PlusExpressionFactory factory;
            return factory;
        }

    private:
        static bool _registered;

        // Can NOT be inherited:
        PlusExpressionFactory() {}

        virtual bool _create( SyntaxTree &tree, int begin) override
        {
            if ( begin + 2 >= tree.size)
                return false;
            SyntaxTree::Node const &left = tree[ begin];
            SyntaxTree::Node const &middle = *( left.next);
            SyntaxTree::Node const &right = *( middle.next);
            if ( middle.is_expression() || middle.character != '+'
                    || left.is_character() || right.is_character())
                return false;
            PlusExpression *exp;
            try {
                exp = new PlusExpression( left.expression, right.expression);
            } catch ( exception &e) {
                string msg( "error: fail to create plus instance: ");
                msg += e.what();
                throw msg;
            }
            tree.compose( begin, begin + 3, exp);
            return true;
        }
};

bool
PlusExpressionFactory::_registered =
    GroupExpressionFactory::instance().registering( &PlusExpressionFactory::instance());


