
#include <string>

#include "expression.h"
#include "syntax_tree.h"
#include "equal_or_not_expression_factory.h"

using namespace std;

class NotEqualExpressionFactory;

class NotEqualExpression : public Expression {
    friend class NotEqualExpressionFactory;
    private:
        Expression *_left, *_right;
        NotEqualExpression( Expression *left, Expression *right)
            : _left( left), _right( right)
        {
        }
        virtual void detach() noexcept override
        {
            _left = NULL;
            _right = NULL;
        }

    public:
        virtual ~NotEqualExpression() noexcept
        {
            if ( _left)
                delete _left;
            if ( _right)
                delete _right;
        }

        virtual int eval() override
        {
            return _left->eval() != _right->eval();
        }
};

class NotEqualExpressionFactory : public EqualOrNotExpressionFactory {
    public:
        static NotEqualExpressionFactory &instance() noexcept
        {
            static NotEqualExpressionFactory factory;
            return factory;
        }

    private:
        static bool _registered;

        // Can NOT be inherited:
        NotEqualExpressionFactory() {}

        virtual bool _create( SyntaxTree &tree, int begin) override
        {
            if ( begin + 3 >= tree.size)
                return false;
            SyntaxTree::Node const &left = tree[ begin];
            SyntaxTree::Node const &middle1 = *( left.next);
            SyntaxTree::Node const &middle2 = *( middle1.next);
            SyntaxTree::Node const &right = *( middle2.next);
            if ( left.is_character() || right.is_character()
                    || middle1.is_expression() || middle1.character != '!'
                    || middle2.is_expression() || middle2.character != '=')
                return false;
            NotEqualExpression *exp;
            try {
                exp = new NotEqualExpression( left.expression, right.expression);
            } catch ( exception &e) {
                string msg( "error: fail to create not-equal instance: ");
                msg += e.what();
                throw msg;
            }
            tree.compose( begin, begin + 4, exp);
            return true;
        }
};

bool
NotEqualExpressionFactory::_registered =
    EqualOrNotExpressionFactory::instance().registering( &NotEqualExpressionFactory::instance());


