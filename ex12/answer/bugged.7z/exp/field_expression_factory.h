#ifndef _FIELD_EXPRESSION_FACTORY_H
#define _FIELD_EXPRESSION_FACTORY_H

#include "syntax_tree.h"
#include "expression_factory.h"

class FieldExpressionFactory : public ExpressionFactory {
    private:
        static bool _registered;

        virtual bool _create( SyntaxTree &tree, int begin) override;

    public:
        static FieldExpressionFactory &instance() noexcept;
        virtual unsigned priority() const noexcept override;

};

#endif

