
#include <string>

#include "expression.h"
#include "syntax_tree.h"
#include "equal_or_not_expression_factory.h"

using namespace std;

class EqualExpressionFactory;

class EqualExpression : public Expression {
    friend class EqualExpressionFactory;
    private:
        Expression *_left, *_right;
        EqualExpression( Expression *left, Expression *right)
            : _left( left), _right( right)
        {
        }
        virtual void detach() noexcept override
        {
            _left = NULL;
            _right = NULL;
        }

    public:
        virtual ~EqualExpression() noexcept
        {
            if ( _left)
                delete _left;
            if ( _right)
                delete _right;
        }

        virtual int eval() override
        {
            return _left->eval() == _right->eval();
        }
};

class EqualExpressionFactory : public EqualOrNotExpressionFactory {
    public:
        static EqualExpressionFactory &instance() noexcept
        {
            static EqualExpressionFactory factory;
            return factory;
        }

    private:
        static bool _registered;

        // Can NOT be inherited:
        EqualExpressionFactory() {}

        virtual bool _create( SyntaxTree &tree, int begin) override
        {
            if ( begin + 3 >= tree.size)
                return false;
            SyntaxTree::Node const &left = tree[ begin];
            SyntaxTree::Node const &middle1 = *( left.next);
            SyntaxTree::Node const &middle2 = *( middle1.next);
            SyntaxTree::Node const &right = *( middle2.next);
            if ( left.is_character() || right.is_character()
                    || middle1.is_expression() || middle1.character != '='
                    || middle2.is_expression() || middle2.character != '=')
                return false;
            EqualExpression *exp;
            try {
                exp = new EqualExpression( left.expression, right.expression);
            } catch ( exception &e) {
                string msg( "error: fail to create equal instance: ");
                msg += e.what();
                throw msg;
            }
            tree.compose( begin, begin + 4, exp);
            return true;
        }
};

bool
EqualExpressionFactory::_registered =
    EqualOrNotExpressionFactory::instance().registering( &EqualExpressionFactory::instance());


