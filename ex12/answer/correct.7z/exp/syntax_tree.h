#ifndef _SYNTAX_TREE_H
#define _SYNTAX_TREE_H

class Expression;

class SyntaxTree {
    public:
        struct Node {
            Node *next;
            Node *child;
            Expression *expression;
            char character;
            inline bool is_expression() const { return expression;}
            inline bool is_character() const { return ! expression;}
        };
    private:
        Node *_head;
        int _size;

    public:
        int &size;
        SyntaxTree( char const *str, int begin, int end);
        ~SyntaxTree();

        // combine nodes from begin ( included ) to end ( not included ) into exp:
        void compose( int begin, int end, Expression *exp);

        // tear expression in node idx apart into original nodes:
        void decompose( int idx);

        Node const &operator[]( int idx) const;

};

#endif

