
#include <string>

#include "expression.h"
#include "syntax_tree.h"
#include "expression_factory.h"

using namespace std;

class AndExpressionFactory;

class AndExpression : public Expression {
    friend class AndExpressionFactory;
    private:
        Expression *_left, *_right;
        AndExpression( Expression *left, Expression *right)
            : _left( left), _right( right)
        {
        }
        virtual void detach() noexcept override
        {
            _left = NULL;
            _right = NULL;
        }

    public:
        virtual ~AndExpression() noexcept
        {
            if ( _left)
                delete _left;
            if ( _right)
                delete _right;
        }

        virtual int eval() override
        {
            return _left->eval() && _right->eval();
        }
};

class AndExpressionFactory : public ExpressionFactory {
    public:
        virtual unsigned priority() const noexcept override
        {
            return 11;
        }
        static AndExpressionFactory &instance() noexcept
        {
            static AndExpressionFactory factory;
            return factory;
        }

    private:
        static bool _registered;

        // Can NOT be inherited:
        AndExpressionFactory() {}

        virtual bool _create( SyntaxTree &tree, int begin) override
        {
            if ( begin + 3 >= tree.size)
                return false;
            SyntaxTree::Node const &left = tree[ begin];
            SyntaxTree::Node const &middle1 = *( left.next);
            SyntaxTree::Node const &middle2 = *( middle1.next);
            SyntaxTree::Node const &right = *( middle2.next);
            if ( left.is_character() || right.is_character()
                    || middle1.is_expression() || middle1.character != '&'
                    || middle2.is_expression() || middle2.character != '&')
                return false;
            AndExpression *exp;
            try {
                exp = new AndExpression( left.expression, right.expression);
            } catch ( exception &e) {
                string msg( "error: fail to create and instance: ");
                msg += e.what();
                throw msg;
            }
            tree.compose( begin, begin + 4, exp);
            return true;
        }
};

bool
AndExpressionFactory::_registered =
    ExpressionFactory::instance().registering( &AndExpressionFactory::instance());


