
#include <string>

#include "expression.h"
#include "syntax_tree.h"
#include "expression_factory.h"

using namespace std;

class OrExpressionFactory;

class OrExpression : public Expression {
    friend class OrExpressionFactory;
    private:
        Expression *_left, *_right;
        OrExpression( Expression *left, Expression *right)
            : _left( left), _right( right)
        {
        }
        virtual void detach() noexcept override
        {
            _left = NULL;
            _right = NULL;
        }

    public:
        virtual ~OrExpression() noexcept
        {
            if ( _left)
                delete _left;
            if ( _right)
                delete _right;
        }

        virtual int eval() override
        {
            return _left->eval() || _right->eval();
        }
};

class OrExpressionFactory : public ExpressionFactory {
    public:
        virtual unsigned priority() const noexcept override
        {
            return 12;
        }
        static OrExpressionFactory &instance() noexcept
        {
            static OrExpressionFactory factory;
            return factory;
        }

    private:
        static bool _registered;

        // Can NOT be inherited:
        OrExpressionFactory() {}

        virtual bool _create( SyntaxTree &tree, int begin) override
        {
            if ( begin + 3 >= tree.size)
                return false;
            SyntaxTree::Node const &left = tree[ begin];
            SyntaxTree::Node const &middle1 = *( left.next);
            SyntaxTree::Node const &middle2 = *( middle1.next);
            SyntaxTree::Node const &right = *( middle2.next);
            if ( left.is_character() || right.is_character()
                    || middle1.is_expression() || middle1.character != '|'
                    || middle2.is_expression() || middle2.character != '|')
                return false;
            OrExpression *exp;
            try {
                exp = new OrExpression( left.expression, right.expression);
            } catch ( exception &e) {
                string msg( "error: fail to create or instance: ");
                msg += e.what();
                throw msg;
            }
            tree.compose( begin, begin + 4, exp);
            return true;
        }
};

bool
OrExpressionFactory::_registered =
    ExpressionFactory::instance().registering( &OrExpressionFactory::instance());


