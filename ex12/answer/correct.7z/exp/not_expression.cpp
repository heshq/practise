#include <string>

#include "expression.h"
#include "syntax_tree.h"
#include "expression_factory.h"

using namespace std;

class NotExpressionFactory;

class NotExpression : public Expression {
    friend class NotExpressionFactory;
    private:
        Expression *_inner;
        NotExpression( Expression *inner)
            : _inner( inner)
        {
        }
        virtual void detach() noexcept override
        {
            _inner = NULL;
        }

    public:
        virtual ~NotExpression() noexcept
        {
            if ( _inner)
                delete _inner;
        }

        virtual int eval() override
        {
            return ! _inner->eval();
        }
};

class NotExpressionFactory : public ExpressionFactory {
    public:
        virtual unsigned priority() const noexcept override
        {
            return 2;
        }
        static NotExpressionFactory &instance()
        {
            static NotExpressionFactory factory;
            return factory;
        }

    private:
        static bool _registered;

        // Can NOT be inherited:
        NotExpressionFactory() {}

        virtual bool _create( SyntaxTree &tree, int begin) override
        {
            if ( begin + 1 >= tree.size)
                return false;
            SyntaxTree::Node const &node = tree[ begin];
            if ( node.is_expression() || node.character != '!' || node.next->is_character())
                return false;
            NotExpression *exp;
            try {
                exp = new NotExpression( node.next->expression);
            } catch ( exception &e) {
                string msg( "error: fail to create not instance: ");
                msg += e.what();
                throw msg;
            }
            tree.compose( begin, begin + 2, exp);
            return true;
        }
};

bool
NotExpressionFactory::_registered =
    ExpressionFactory::instance().registering( &NotExpressionFactory::instance());


