
#include <string>

#include "expression.h"
#include "syntax_tree.h"
#include "expression_factory.h"

using namespace std;

class BitOrExpressionFactory;

class BitOrExpression : public Expression {
    friend class BitOrExpressionFactory;
    private:
        Expression *_left, *_right;
        BitOrExpression( Expression *left, Expression *right)
            : _left( left), _right( right)
        {
        }
        virtual void detach() noexcept override
        {
            _left = NULL;
            _right = NULL;
        }

    public:
        virtual ~BitOrExpression() noexcept
        {
            if ( _left)
                delete _left;
            if ( _right)
                delete _right;
        }

        virtual int eval() override
        {
            return _left->eval() | _right->eval();
        }
};

class BitOrExpressionFactory : public ExpressionFactory {
    public:
        virtual unsigned priority() const noexcept override
        {
            return 10;
        }
        static BitOrExpressionFactory &instance() noexcept
        {
            static BitOrExpressionFactory factory;
            return factory;
        }

    private:
        static bool _registered;

        // Can NOT be inherited:
        BitOrExpressionFactory() {}

        virtual bool _create( SyntaxTree &tree, int begin) override
        {
            if ( begin + 2 >= tree.size)
                return false;
            SyntaxTree::Node const &left = tree[ begin];
            SyntaxTree::Node const &middle = *( left.next);
            SyntaxTree::Node const &right = *( middle.next);
            if ( middle.is_expression() || middle.character != '|'
                    || left.is_character() || right.is_character())
                return false;
            BitOrExpression *exp;
            try {
                exp = new BitOrExpression( left.expression, right.expression);
            } catch ( exception &e) {
                string msg( "error: fail to create bit-or instance: ");
                msg += e.what();
                throw msg;
            }
            tree.compose( begin, begin + 3, exp);
            return true;
        }
};

bool
BitOrExpressionFactory::_registered =
    ExpressionFactory::instance().registering( &BitOrExpressionFactory::instance());


