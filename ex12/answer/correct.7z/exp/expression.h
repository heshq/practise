#ifndef _EXPRESSION_H
#define _EXPRESSION_H

#include <string>

class ExpressionFactory;

class Expression {
    friend class ExpressionFactory;
    protected:
        // remove ownership of all child expressions
        virtual void detach() noexcept = 0;
    public:
        virtual ~Expression() noexcept;

        // Factories:
        static Expression *parse( std::string const &str, int begin = 0, int end = -1);
        static Expression *parse( char const *str, int begin = 0, int end = -1);

        virtual int eval() = 0;
};


#endif



