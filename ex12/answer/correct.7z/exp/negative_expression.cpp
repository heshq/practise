#include <string>

#include "expression.h"
#include "syntax_tree.h"
#include "expression_factory.h"

using namespace std;

class NegativeExpressionFactory;

class NegativeExpression : public Expression {
    friend class NegativeExpressionFactory;
    private:
        Expression *_inner;
        NegativeExpression( Expression *inner)
            : _inner( inner)
        {
        }
        virtual void detach() noexcept override
        {
            _inner = NULL;
        }

    public:
        virtual ~NegativeExpression() noexcept
        {
            if ( _inner)
                delete _inner;
        }

        virtual int eval() override
        {
            return - _inner->eval();
        }
};

class NegativeExpressionFactory : public ExpressionFactory {
    public:
        virtual unsigned priority() const noexcept override
        {
            return 2;
        }
        static NegativeExpressionFactory &instance()
        {
            static NegativeExpressionFactory factory;
            return factory;
        }

    private:
        static bool _registered;

        // Can NOT be inherited:
        NegativeExpressionFactory() {}

        virtual bool _create( SyntaxTree &tree, int begin) override
        {
            if ( begin + 1 >= tree.size)
                return false;
            SyntaxTree::Node const &node = tree[ begin];
            if ( node.is_expression() || node.character != '-' || node.next->is_character())
                return false;
            NegativeExpression *exp;
            try {
                exp = new NegativeExpression( node.next->expression);
            } catch ( exception &e) {
                string msg( "error: fail to create negative instance: ");
                msg += e.what();
                throw msg;
            }
            tree.compose( begin, begin + 2, exp);
            return true;
        }
};

bool
NegativeExpressionFactory::_registered =
    ExpressionFactory::instance().registering( &NegativeExpressionFactory::instance());


