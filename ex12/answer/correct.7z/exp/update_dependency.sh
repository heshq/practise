#!/usr/bin/bash

###
# 
# @File   : update_dependency.sh   
# @Author : alexander.here@gmail.com
# @Date   : 2015-05-11 01:02   
# @Brief  :  
# 
###

TEMP=`mktemp /tmp/$0.XXXXXXX`
if [ "$?" -ne 0 ]
then
	echo 'failed to create temp file.' > /dev/stderr
	exit 1
fi

for file in *.cpp *.h
do
	echo -n "$file :"
	grep -P '#\s*include\s+"' $file | grep -Po '[0-9a-zA-Z_]*\.h' > $TEMP
	if [ `wc -l < $TEMP` -gt 0 ]
	then
		cat $TEMP | while read header
		do
			echo -n " $header"
		done
		echo
		echo -en "\t"
		echo '$(TOUCH) $@'
		echo
	else
		echo
		echo
	fi
done > dependencies.mk

rm $TEMP

# End of 'update_dependency.sh' 

