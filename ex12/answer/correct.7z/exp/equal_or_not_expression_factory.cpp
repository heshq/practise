
#include "equal_or_not_expression_factory.h"

bool
EqualOrNotExpressionFactory::_create( SyntaxTree &tree, int position)
{
    for ( auto it = _factories.begin(); it != _factories.end(); ++ it)
        if ( ( *it)->_create( tree, position))
            return true;
    return false;
}

EqualOrNotExpressionFactory &
EqualOrNotExpressionFactory::instance() noexcept
{
    static EqualOrNotExpressionFactory factory;
    return factory;
}

unsigned
EqualOrNotExpressionFactory::priority() const noexcept
{
    return 7;
}

bool
EqualOrNotExpressionFactory::_registered =
    ExpressionFactory::instance().registering( &EqualOrNotExpressionFactory::instance());


