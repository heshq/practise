
#include "field_expression_factory.h"

bool
FieldExpressionFactory::_create( SyntaxTree &tree, int position)
{
    for ( auto it = _factories.begin(); it != _factories.end(); ++ it)
        if ( ( *it)->_create( tree, position))
            return true;
    return false;
}

FieldExpressionFactory &
FieldExpressionFactory::instance() noexcept
{
    static FieldExpressionFactory factory;
    return factory;
}

unsigned
FieldExpressionFactory::priority() const noexcept
{
    return 3;
}

bool
FieldExpressionFactory::_registered =
    ExpressionFactory::instance().registering( &FieldExpressionFactory::instance());


