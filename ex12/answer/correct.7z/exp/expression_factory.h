#ifndef _EXPRESSION_FACTORY_H
#define _EXPRESSION_FACTORY_H

#include "ordered_list.h"
#include "expression.h"
#include "syntax_tree.h"

class ExpressionFactory;

struct PriorityCompare {
    bool operator()( ExpressionFactory const *a, ExpressionFactory const *b);
};

class ExpressionFactory { // singleton
    private:
        bool _try( ExpressionFactory &factory, SyntaxTree &tree);
        bool _recursion( SyntaxTree &tree);

    protected:
        ordered_list< ExpressionFactory *, PriorityCompare > _factories;
        ExpressionFactory() noexcept;

    public:
        static ExpressionFactory &instance() noexcept;

        bool registering( ExpressionFactory *) noexcept;

        virtual ~ExpressionFactory() noexcept;

        virtual unsigned priority() const noexcept;
        virtual bool left_to_right() const noexcept;

        // interface for derived factories to create expression,
        // derived factories should try to create an expression in tree at position.
        // return false if cannot:
        virtual bool _create( SyntaxTree &tree, int position);
    
        // throw std::string on exception, will NOT return NULL:
        Expression *create( char const *str, int begin, int end);
};

#endif


