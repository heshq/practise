#ifndef _EQUAL_OR_NOT_EXPRESSION_FACTORY_H
#define _EQUAL_OR_NOT_EXPRESSION_FACTORY_H

#include "syntax_tree.h"
#include "expression_factory.h"

class EqualOrNotExpressionFactory : public ExpressionFactory {
    private:
        static bool _registered;

        virtual bool _create( SyntaxTree &tree, int begin) override;

    public:
        static EqualOrNotExpressionFactory &instance() noexcept;
        virtual unsigned priority() const noexcept override;

};

#endif

