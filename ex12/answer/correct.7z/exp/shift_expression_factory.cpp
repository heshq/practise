
#include "shift_expression_factory.h"

bool
ShiftExpressionFactory::_create( SyntaxTree &tree, int position)
{
    for ( auto it = _factories.begin(); it != _factories.end(); ++ it)
        if ( ( *it)->_create( tree, position))
            return true;
    return false;
}

ShiftExpressionFactory &
ShiftExpressionFactory::instance() noexcept
{
    static ShiftExpressionFactory factory;
    return factory;
}

unsigned
ShiftExpressionFactory::priority() const noexcept
{
    return 5;
}

bool
ShiftExpressionFactory::_registered =
    ExpressionFactory::instance().registering( &ShiftExpressionFactory::instance());


