#include <string>
#include <exception>
#include "syntax_tree.h"

using namespace std;

SyntaxTree::SyntaxTree( char const *str, int begin, int end)
    : _head( NULL), _size( 0), size( _size)
{
    if ( begin >= end || ! str) {
        string msg( "error: trying to build syntax info from empty string");
        throw msg;
    }
    for ( int i = end - 1; i >= begin; i --)
        if ( str[ i] != ' ' && str[ i] != '\t') {
            Node *next = _head;
            Node *curr = NULL;
            try {
                _size ++;
                curr = new Node;
                curr->next = next;
                curr->child = NULL;
                curr->expression = NULL;
                curr->character = str[ i];
            } catch ( exception &e) {
                string msg( "error: fail to build syntax info: ");
                msg += e.what();
                while ( _head) {
                    Node *p = _head;
                    _head = _head->next;
                    delete p;
                }
                throw msg;
            }
            _head = curr;
        }
}

SyntaxTree::~SyntaxTree()
{
    while ( _head) {
        Node *p = _head;
        _head = _head->next;
        delete p;
    }
}

void
SyntaxTree::compose( int begin, int end, Expression *exp)
{
    if ( ! exp) {
        string msg( "error: trying to add a null expression into syntax tree");
        throw msg;
    }
    if ( begin >= end) {
        string msg( "error: wrong range of nodes to compose");
        throw msg;
    }
    if ( begin >= size || end > size) {
        string msg( "error: trying to compose nodes out of ranged");
        throw msg;
    }
    int i = 0;
    Node *node_before_begin = NULL;
    Node *node_begin = _head;
    while ( i < begin) {
        node_before_begin = node_begin;
        node_begin = node_begin->next;
        i ++;
    }
    int count = 0;
    Node *node_end = node_begin;
    while ( i < end - 1) {
        node_end = node_end->next;
        count ++;
        i ++;
    }
    Node *new_node;
    try {
        new_node = new Node;
    } catch ( exception &e) {
        string msg( "error: fail to grow syntax tree: ");
        msg += e.what();
        throw msg;
    }
    new_node->child = node_begin;
    new_node->next = node_end->next;
    new_node->expression = exp;
    node_end->next = NULL;
    if ( _head == node_begin)
        _head = new_node;
    else
        node_before_begin->next = new_node;
    _size -= count;
}

void
SyntaxTree::decompose( int idx)
{
    if ( idx > size) {
        string msg( "error: trying to decompose node out of range");
        throw msg;
    }
    Node *node_before;
    Node *node_to_delete = _head;
    while ( idx --) {
        node_before = node_to_delete;
        node_to_delete = node_to_delete->next;
    }
    if ( node_to_delete->is_character()) {
        string msg( "error: trying to decompose leaf node in syntax tree");
        throw msg;
    }
    // Insert bug here: delete member expression
    if ( node_to_delete == _head)
        _head = node_to_delete->child;
    else
        node_before->next = node_to_delete->child;
    int count = 0;
    Node *last_child = node_to_delete->child;
    while ( last_child->next) {
        last_child = last_child->next;
        count ++;
    }
    last_child->next = node_to_delete->next;
    delete node_to_delete;
    size += count;
}

SyntaxTree::Node const &
SyntaxTree::operator[]( int idx) const
{
    if ( idx < 0 || idx > size) {
        string msg( "error: trying to fetch out of ranged node in syntax tree");
        throw msg;
    }
    Node *p = _head;
    while ( idx --)
        if ( p->next)
           p = p->next;
    return *p;
}

