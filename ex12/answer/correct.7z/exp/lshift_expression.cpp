
#include <string>

#include "expression.h"
#include "syntax_tree.h"
#include "shift_expression_factory.h"

using namespace std;

class LShiftExpressionFactory;

class LShiftExpression : public Expression {
    friend class LShiftExpressionFactory;
    private:
        Expression *_left, *_right;
        LShiftExpression( Expression *left, Expression *right)
            : _left( left), _right( right)
        {
        }
        virtual void detach() noexcept override
        {
            _left = NULL;
            _right = NULL;
        }

    public:
        virtual ~LShiftExpression() noexcept
        {
            if ( _left)
                delete _left;
            if ( _right)
                delete _right;
        }

        virtual int eval() override
        {
            int left = _left->eval();
            int right = _right->eval();
            if ( right >= 0)
                return left << right;
            else
                return left >> -right;
        }
};

class LShiftExpressionFactory : public ShiftExpressionFactory {
    public:
        static LShiftExpressionFactory &instance() noexcept
        {
            static LShiftExpressionFactory factory;
            return factory;
        }

    private:
        static bool _registered;

        // Can NOT be inherited:
        LShiftExpressionFactory() {}

        virtual bool _create( SyntaxTree &tree, int begin) override
        {
            if ( begin + 3 >= tree.size)
                return false;
            SyntaxTree::Node const &left = tree[ begin];
            SyntaxTree::Node const &middle1 = *( left.next);
            SyntaxTree::Node const &middle2 = *( middle1.next);
            SyntaxTree::Node const &right = *( middle2.next);
            if ( left.is_character() || right.is_character()
                    || middle1.is_expression() || middle1.character != '<'
                    || middle2.is_expression() || middle2.character != '<')
                return false;
            LShiftExpression *exp;
            try {
                exp = new LShiftExpression( left.expression, right.expression);
            } catch ( exception &e) {
                string msg( "error: fail to create shift-left instance: ");
                msg += e.what();
                throw msg;
            }
            tree.compose( begin, begin + 4, exp);
            return true;
        }
};

bool
LShiftExpressionFactory::_registered =
    ShiftExpressionFactory::instance().registering( &LShiftExpressionFactory::instance());


