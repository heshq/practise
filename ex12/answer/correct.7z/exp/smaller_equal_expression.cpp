
#include <string>

#include "expression.h"
#include "syntax_tree.h"
#include "compare_expression_factory.h"

using namespace std;

class SmallerEqualExpressionFactory;

class SmallerEqualExpression : public Expression {
    friend class SmallerEqualExpressionFactory;
    private:
        Expression *_left, *_right;
        SmallerEqualExpression( Expression *left, Expression *right)
            : _left( left), _right( right)
        {
        }
        virtual void detach() noexcept override
        {
            _left = NULL;
            _right = NULL;
        }

    public:
        virtual ~SmallerEqualExpression() noexcept
        {
            if ( _left)
                delete _left;
            if ( _right)
                delete _right;
        }

        virtual int eval() override
        {
            return _left->eval() <= _right->eval();
        }
};

class SmallerEqualExpressionFactory : public CompareExpressionFactory {
    public:
        static SmallerEqualExpressionFactory &instance() noexcept
        {
            static SmallerEqualExpressionFactory factory;
            return factory;
        }

    private:
        static bool _registered;

        // Can NOT be inherited:
        SmallerEqualExpressionFactory() {}

        virtual bool _create( SyntaxTree &tree, int begin) override
        {
            if ( begin + 3 >= tree.size)
                return false;
            SyntaxTree::Node const &left = tree[ begin];
            SyntaxTree::Node const &middle1 = *( left.next);
            SyntaxTree::Node const &middle2 = *( middle1.next);
            SyntaxTree::Node const &right = *( middle2.next);
            if ( left.is_character() || right.is_character()
                    || middle1.is_expression() || middle1.character != '<'
                    || middle2.is_expression() || middle2.character != '=')
                return false;
            SmallerEqualExpression *exp;
            try {
                exp = new SmallerEqualExpression( left.expression, right.expression);
            } catch ( exception &e) {
                string msg( "error: fail to create smaller-or-equal instance: ");
                msg += e.what();
                throw msg;
            }
            tree.compose( begin, begin + 4, exp);
            return true;
        }
};

bool
SmallerEqualExpressionFactory::_registered =
    CompareExpressionFactory::instance().registering( &SmallerEqualExpressionFactory::instance());


