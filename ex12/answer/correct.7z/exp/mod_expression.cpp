
#include <string>

#include "expression.h"
#include "syntax_tree.h"
#include "field_expression_factory.h"

using namespace std;

class ModExpressionFactory;

class ModExpression : public Expression {
    friend class ModExpressionFactory;
    private:
        Expression *_left, *_right;
        ModExpression( Expression *left, Expression *right)
            : _left( left), _right( right)
        {
        }
        virtual void detach() noexcept override
        {
            _left = NULL;
            _right = NULL;
        }

    public:
        virtual ~ModExpression() noexcept
        {
            if ( _left)
                delete _left;
            if ( _right)
                delete _right;
        }

        virtual int eval() override
        {
            int right = _right->eval();
            if ( ! right) { // IF NOT RIGHT
                string msg( "error: divide by zero");
                throw msg;
            }
            int left = _left->eval();
            return left % right;
        }
};

class ModExpressionFactory : public FieldExpressionFactory {
    public:
        static ModExpressionFactory &instance() noexcept
        {
            static ModExpressionFactory factory;
            return factory;
        }

    private:
        static bool _registered;

        // Can NOT be inherited:
        ModExpressionFactory() {}

        virtual bool _create( SyntaxTree &tree, int begin) override
        {
            if ( begin + 2 >= tree.size)
                return false;
            SyntaxTree::Node const &left = tree[ begin];
            SyntaxTree::Node const &middle = *( left.next);
            SyntaxTree::Node const &right = *( middle.next);
            if ( middle.is_expression() || middle.character != '%'
                    || left.is_character() || right.is_character())
                return false;
            ModExpression *exp;
            try {
                exp = new ModExpression( left.expression, right.expression);
            } catch ( exception &e) {
                string msg( "error: fail to create mod instance: ");
                msg += e.what();
                throw msg;
            }
            tree.compose( begin, begin + 3, exp);
            return true;
        }
};

bool
ModExpressionFactory::_registered =
    FieldExpressionFactory::instance().registering( &ModExpressionFactory::instance());


