#ifndef _SOLVE_H
#define _SOLVE_H

#include <vector>

#include "sudoku.h"

void solve( Sudoku const &sudoku, std::vector< Sudoku> &anwsers); 

#endif

